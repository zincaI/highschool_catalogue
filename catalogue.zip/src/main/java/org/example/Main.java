package org.example;

import java.io.IOException;
//import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        try {
            // Încarcă toți utilizatorii,materiile,notele din fișierul JSON
            List<AppUser> users = AppUser.loadUsers();
            List<Subject> subjects = Subject.loadUsers();
            List<Grade> grades = Grade.loadGrades();

            AppUser appConnectedUser=null;

            Scanner scanner = new Scanner(System.in);

            boolean foundUser = false;

                while(foundUser==false) {
                    System.out.print("Introduce email: ");
                    String inputEmail = scanner.nextLine();
                    System.out.print("Introduce password: ");
                    String inputPassword = scanner.nextLine();

                    for (AppUser user : users) {
                        if (user.getEmail().equals(inputEmail) && user.getPassword().equals(inputPassword)) {
                            foundUser = true;
                            appConnectedUser = user;
                            break; // Ieșiți din buclă când găsiți o potrivire
                        }
                    }
                    if(foundUser){
                        System.out.println("You are now connected in the catalogue");
                        break;
                    }
                    }

            if(foundUser) {
                if(appConnectedUser.getRole().equals("teacher")) {
                   int subjectId = 0;

                    int value = -1;
                    while(value!=0){
                        System.out.println("The cases are:");
                        System.out.println("0. Exit");
                        System.out.println("1. View the students with their ids");
                        System.out.println("2. View student names, ids, and grades");
                        System.out.println("3. Add grade to student");
                        System.out.println("4. Average grade per subject");
                        System.out.println("5. Delete grade");
                        System.out.println("6. Sort students alphabetically ");
                        System.out.println("7. Sort grades after date");

                        System.out.print("Introduce value: ");
                        value = scanner.nextInt();
                    switch(value){
                        case 0:
                            break;
                        case 1:
                            for (AppUser user : users) {
                                if(user.getRole().equals("student")){
                                System.out.println("ID: " + user.getId());
                                System.out.println("First Name: " + user.getFirstName());
                                System.out.println("Last Name: " + user.getLastName());
                                System.out.println();
                            }}
                            break;
                        case 2:
                            // Iterate over the grades
                            for (Grade grade : grades) {
                                // Find the student associated with the grade
                                AppUser student = findUserById(users, grade.getAppId());
                                // Find the subject associated with the grade
                                Subject subject = findSubjectByIdSubject(subjects, grade.getSubjectId());

                                // Print student, grade, and subject information
                                if (student != null && subject != null) {
                                    System.out.println("Student id: " + student.getId());
                                    System.out.println("Student: " + student.getFirstName() + " " + student.getLastName());
                                    System.out.println("Grade: " + grade.getValue());
                                    System.out.println("Subject: " + subject.getName());
                                    System.out.println();
                                }
                            }

                            break;
                        case 3:
                            System.out.println("Introduce student id: ");
                            int studentId = scanner.nextInt(); // ID-ul studentului
                            scanner.nextLine();

                            System.out.println("Introduce subject id: ");
                            subjectId = scanner.nextInt(); // ID-ul studentului
                            Subject subject = findSubjectByIdSubject(subjects, subjectId);
                            scanner.nextLine();


                            AppUser student = findUserById(users, studentId);
                                if (student != null && subject != null&&student.getRole().equals("student")&&appConnectedUser.getId() == subject.getAppId()) {
                                    Grade grade = new Grade();
                                    System.out.println("Introduce grade id: ");
                                    int gradeId= scanner.nextInt();
                                    scanner.nextLine();
                                    System.out.println("Introduce grade: ");
                                    int newGrade= scanner.nextInt();

                                    grade.setGradeId(gradeId);
                                    grade.setValue(newGrade); // notă
                                    grade.setAppId(student.getId());
                                    scanner.nextLine();

                                    System.out.println("Introduce date: ");

                                    String date=scanner.nextLine();// Setăm ID-ul studentului ca AppId pentru notă
                                    grade.setDate(date); // Setăm data curentă
                                    grade.setSubjectId(subject.getIdSubject()); // Setăm ID-ul materiei pentru notă

                                    grade.save(); // Salvăm nota în fișierul JSON


                                        System.out.println("The grade was added succesfully to" + student.getFirstName() + " " + student.getLastName() + " at the subject " + subject.getName());
                                } else {
                                    System.out.println("The student or the subject were introduced incorrectly");
                                }

                            break;
                        case 4:
                            // Obține ID-ul subiectului asociat profesorului conectat
                            subjectId=findSubjectByUserId(subjects,appConnectedUser.getId()).getIdSubject();
                            // Creează o instanță a clasei Main
                            Main mainInstance = new Main();
                            System.out.println("Introduce student id student: ");
                            int idSt= scanner.nextInt();
                            scanner.nextLine();

                            // Apelarea metodei non-statice calculateAverageGradeForSubject folosind instanța Main
                            double averageGrade = mainInstance.calculateAverageGradeForSubject(grades, subjectId,idSt);
                            // Afisarea rezultatului
                            System.out.println("The average grade for the subject with the id " + subjectId + " with the teacher's id  " + appConnectedUser.getId() + " is: " + averageGrade);
                            break;
                        case 5:
                            // Introdu ID-ul notei pe care dorești să o ștergi
                            System.out.println("Introduce the grade's id: ");
                            int gradeToDelete = scanner.nextInt();
                            scanner.nextLine(); // Pentru a consuma newline-ul

                            boolean deleted = false; // Flag pentru a verifica daca nota a fost stearsa


                            // Itereaza prin lista de grade
                            for (Grade grade : grades) {
                                // Verifica daca ID-ul notei este egal cu ID-ul notei pe care dorim sa o stergem
                                if (grade.getGradeId() == gradeToDelete) {
                                    // Sterge nota din lista
                                    if(grade.getSubjectId()==findSubjectByUserId(subjects,appConnectedUser.getId()).getIdSubject()) {
                                        grades.remove(grade);
                                        deleted = true;
                                    }
                                    else {
                                        System.out.println("The teacher can't alter this grade");
                                        break;
                                    }

                                    // Afiseaza un mesaj de confirmare
                                    System.out.println("The grade was deleted succesfully.");
                                    break; // Iesi din bucla dupa ce ai sters prima nota cu ID-ul dat
                                }
                            }

                            // Verifica daca nota a fost stearsa
                            if (!deleted) {
                                System.out.println("There is no grade with the id " + gradeToDelete);
                            }
                            break;
                        case 6:
                            List<AppUser> students = users.stream()
                                    .filter(user -> user.getRole().equals("student"))
                                    .collect(Collectors.toList());

                            // Sortăm lista de studenți după surname
                            students.sort((student1, student2) -> student1.getLastName().compareToIgnoreCase(student2.getLastName()));

                            // Afișăm lista de studenți sortată
                            System.out.println("SDtudents sorted after students' surnames:");
                            for (AppUser s : students) {
                                System.out.println("ID: " + s.getId() + ", Surname: " + s.getLastName() + ", Firstname: " + s.getFirstName());
                            }

                            break;
                        case 7:
                            grades.sort(Comparator.comparing(Grade::getDate)
                                    .thenComparing(grade -> {
                                        AppUser st = findUserById(users, grade.getAppId());
                                        return st != null ? st.getLastName() : "";
                                    })
                                    .thenComparing(grade -> {
                                        Subject s = findSubjectByIdSubject(subjects, grade.getSubjectId());
                                        return s != null ? s.getName() : "";
                                    }));

                            // Afișăm lista de note sortată după data calendaristică, numele studentului și numele materiei
                            System.out.println("Grade sorted by date:");
                            for (Grade grade : grades) {
                                AppUser st = findUserById(users, grade.getAppId());
                                Subject s = findSubjectByIdSubject(subjects, grade.getSubjectId());
                                System.out.println("Date: " + grade.getDate() + ", Student name: " + (st != null ? st.getLastName() : "") + (st != null ? st.getFirstName() : "")
                                        + ", Subject: " + (s != null ? s.getName() : "") + ", Grade: " + grade.getValue());
                            }
                            break;
                        default:
                            System.out.println("This is not a valid value");
                            break;
                    }}
                }
                else{
                    int value=-1;
                    int studentId = appConnectedUser.getId();

                    while(value!=0){
                        System.out.println("0. Exit 1. Show notes");
                        System.out.println("Introduce value: ");
                        value=scanner.nextInt();

                        switch (value){
                        case 0:
                            break;
                            case 1:
                    // Afisăm notele elevului pentru fiecare disciplină și data asociată
                    System.out.println("Grades: ");
                    for (Grade grade : grades) {
                        // Verificăm dacă nota este asociată elevului dorit
                        if (grade.getAppId() == studentId) {
                            // Găsim numele elevului
                            AppUser student = findUserById(users, studentId);

                            // Găsim numele materiei
                            Subject subject = findSubjectByIdSubject(subjects, grade.getSubjectId());

                            // Afișăm nota, data și disciplina asociate
                            System.out.println("Date: " + grade.getDate() + ", Subject: " + (subject != null ? subject.getName() : "N/A") +
                                    ", Grade: " + grade.getValue());
                        }
                    }
                    break;

                    }
                }

            }
            scanner.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
    private static AppUser findUserById(List<AppUser> users, int userId) {
        for (AppUser user : users) {
            if (user.getId() == userId) {
                return user;
            }
        }
        return null; // Returnăm null dacă nu găsim un utilizator cu ID-ul dat
    }

    // Metodă pentru a găsi o materie după ID
    private static Subject findSubjectByIdSubject(List<Subject> subjects, int subjectId) {
        for (Subject subject : subjects) {
            if (subject.getIdSubject() == subjectId) {
                return subject;
            }
        }
        return null; // Returnăm null dacă nu găsim o materie cu ID-ul dat
    }

    private static Subject findSubjectByUserId(List<Subject> subjects, int UserId) {
        for (Subject subject : subjects) {
            if (subject.getAppId() == UserId) {
                return subject;
            }
        }
        return null; // Returnăm null dacă nu găsim o materie cu ID-ul dat
    }

    public double calculateAverageGradeForSubject(List<Grade> grades, int subjectId,int student) {
        double totalGrade = 0;
        int count = 0;

        // Parcurgi toate notele pentru subiectul dat
        for (Grade grade : grades) {
            // Verifici dacă nota este asociată subiectului și profesorului dat
            if (grade.getSubjectId() == subjectId&&student==grade.getAppId()) {
                totalGrade += grade.getValue();
                count++;
            }
        }

        // Calculezi media
        if (count > 0) {
            return totalGrade / count;
        } else {
            return 0; // sau arunca o exceptie, in functie de logica aplicatiei
        }
    }

}

